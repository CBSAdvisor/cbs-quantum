Public Class Form1

#Region "Needed to close pinned Dropdown when the Form Sizes or Moves"

    Private Sub Form1_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Move
        For Each c As Control In Me.Controls
            If c.GetType Is GetType(DropDownContainer.DDContainer) Then
                CType(c, DropDownContainer.DDContainer).ForceCloseDropDown()
            End If
        Next
    End Sub

    Private Sub Form1_ResizeBegin(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.ResizeBegin
        For Each c As Control In Me.Controls
            If c.GetType Is GetType(DropDownContainer.DDContainer) Then
                CType(c, DropDownContainer.DDContainer).ForceCloseDropDown()
            End If
        Next
    End Sub

#End Region 'Needed to close pinned Dropdown when the Form Sizes or Moves

#Region "Demo Stuff"

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        DDContainer1.CloseDropDown()
    End Sub

    Private Sub MonthCalendar1_DateChanged(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles MonthCalendar1.DateChanged
        ddcCalendar.Text = MonthCalendar1.SelectionRange.Start
        ddcCalendar.CloseDropDown()
    End Sub

    Private Sub ddcShapeRadioButtons_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles RadioButton7.CheckedChanged, RadioButton6.CheckedChanged, RadioButton5.CheckedChanged

        ddcShape.Text = sender.text

        Dim bm As Bitmap = New Bitmap(30, ddcShape.HeaderHeight)
        Dim g As Graphics = Graphics.FromImage(bm)
        Dim rect As Rectangle = New Rectangle(3, 3, 24, 13)
        Select Case sender.text
            Case "None"
                ddcShape.GraphicImage = Nothing

            Case "Ellipse"
                g.FillEllipse(Brushes.Gold, rect)
                g.DrawEllipse(Pens.Blue, rect)
                ddcShape.GraphicImage = bm.Clone

            Case "Rectangle"
                g.FillRectangle(Brushes.Gold, rect)
                g.DrawRectangle(Pens.Blue, rect)
                ddcShape.GraphicImage = bm.Clone

        End Select
        bm.Dispose()
        g.Dispose()
        ddcShape.CloseDropDown()


    End Sub


    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles Button2.Click, Button10.Click, Button9.Click, Button8.Click, _
                Button7.Click, Button6.Click, Button5.Click, Button11.Click
        ddcScrollPanel.Text = String.Format("Button {0}", CType(sender, Button).Text)

    End Sub

    Private Sub ddcRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles RadioButton1.CheckedChanged, RadioButton2.CheckedChanged, _
                RadioButton3.CheckedChanged, RadioButton4.CheckedChanged
        ddcRadioButtons.Text = CType(sender, RadioButton).Text
        ddcRadioButtons.CloseDropDown()
    End Sub

    Private Sub TreeView1_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView1.AfterSelect
        ddcTreeview.Text = e.Node.Text
    End Sub

    Private Sub butRndKnownColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butRndKnownColor.Click
        Dim generator As New Random
        Dim randomValue As Integer
        randomValue = generator.Next(KnownColor.AliceBlue, KnownColor.YellowGreen)

        ddcNoText.ButtonBackColor = Color.FromKnownColor(randomValue)
        ddcNoText.PinHighlight = Color.FromKnownColor(randomValue)
    End Sub

    Private Sub ddcPictures_DropDown(ByVal sender As System.Object, ByVal IsOpen As System.Boolean) Handles ddcPictures.DropDown
        If ddcPictures.GraphicImage Is Nothing Then
            If IsOpen Then
                ddcPictures.Text = "Click the Picture to select"
            Else
                ddcPictures.Text = "Open Me"
            End If

        End If
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles Jack.Click, Evolution.Click
        ddcPictures.Text = sender.Name
        ddcPictures.GraphicImage = sender.image
        ddcPictures.CloseDropDown()
    End Sub

    Private Sub butClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butClear.Click
        ddcPictures.GraphicImage = Nothing
        ddcPictures.Text = "Click the Picture to select"
    End Sub

#End Region 'Demo Stuff


End Class
