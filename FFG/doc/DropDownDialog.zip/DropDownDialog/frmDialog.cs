//================================================
//| Downloaded From                              |
//| Visual C# Kicks - http://www.vcskicks.com/   |
//================================================

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DropDownDialog
{
    public partial class frmDialog : Form
    {
        public frmDialog(Point startLocation)
        {
            InitializeComponent();

            //Set the style--------------------------------------

            //Remove title bar and set edge-style
            this.Text = string.Empty;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;

            //Disable normal window functions
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.ControlBox = false;
            this.ShowInTaskbar = false;
            this.TopMost = true; //make it appear on the very top
            //----------------------------------------------------

            this.Capture = true; //allows mouse events to be triggered no matter where the mouse clicks

            //Match the position to the parent control
            this.Left = startLocation.X;
            this.Top = startLocation.Y;

        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            //Check to see if the click is inside the drop-down Form
            if (this.RectangleToScreen(this.ClientRectangle).Contains(Cursor.Position))
                base.OnMouseDown(e); //normal mouse behavior
            else
                this.Close(); //close the drop-down
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.vcskicks.com/");
            this.Close();
        }
    }
}