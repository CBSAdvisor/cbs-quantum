<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node0")
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node7")
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node11")
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node10", New System.Windows.Forms.TreeNode() {TreeNode3})
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node8", New System.Windows.Forms.TreeNode() {TreeNode4})
        Dim TreeNode6 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node9")
        Dim TreeNode7 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node5", New System.Windows.Forms.TreeNode() {TreeNode2, TreeNode5, TreeNode6})
        Dim TreeNode8 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node6")
        Dim TreeNode9 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node1", New System.Windows.Forms.TreeNode() {TreeNode7, TreeNode8})
        Dim TreeNode10 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node2")
        Dim TreeNode11 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node12")
        Dim TreeNode12 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node13")
        Dim TreeNode13 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node3", New System.Windows.Forms.TreeNode() {TreeNode11, TreeNode12})
        Dim TreeNode14 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node4")
        Me.Button1 = New System.Windows.Forms.Button
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.DDContainer4 = New DropDownContainer.DDContainer
        Me.Panel7 = New System.Windows.Forms.Panel
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox
        Me.ddcPictures = New DropDownContainer.DDContainer
        Me.PanelPics = New System.Windows.Forms.Panel
        Me.butClear = New System.Windows.Forms.Button
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Jack = New System.Windows.Forms.PictureBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Evolution = New System.Windows.Forms.PictureBox
        Me.ddcScrollPanel = New DropDownContainer.DDContainer
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.Button11 = New System.Windows.Forms.Button
        Me.Button10 = New System.Windows.Forms.Button
        Me.Button9 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.ddcRadioButtons = New DropDownContainer.DDContainer
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.RadioButton4 = New System.Windows.Forms.RadioButton
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.RadioButton3 = New System.Windows.Forms.RadioButton
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.ddcCalendar = New DropDownContainer.DDContainer
        Me.MonthCalendar1 = New System.Windows.Forms.MonthCalendar
        Me.ddcShape = New DropDownContainer.DDContainer
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.RadioButton5 = New System.Windows.Forms.RadioButton
        Me.RadioButton6 = New System.Windows.Forms.RadioButton
        Me.RadioButton7 = New System.Windows.Forms.RadioButton
        Me.DDContainer1 = New DropDownContainer.DDContainer
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.CheckBox2 = New System.Windows.Forms.CheckBox
        Me.Button3 = New System.Windows.Forms.Button
        Me.ddcTreeview = New DropDownContainer.DDContainer
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.TreeView1 = New System.Windows.Forms.TreeView
        Me.ddcNoText = New DropDownContainer.DDContainer
        Me.butRndKnownColor = New System.Windows.Forms.Button
        Me.Panel3.SuspendLayout()
        Me.DDContainer4.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.ddcPictures.SuspendLayout()
        Me.PanelPics.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.Jack, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.Evolution, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ddcScrollPanel.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.ddcRadioButtons.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.ddcCalendar.SuspendLayout()
        Me.ddcShape.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.DDContainer1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.ddcTreeview.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.ddcNoText.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(21, 16)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 34)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.BackgroundImage = CType(resources.GetObject("Panel3.BackgroundImage"), System.Drawing.Image)
        Me.Panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel3.Controls.Add(Me.ddcPictures)
        Me.Panel3.Controls.Add(Me.DDContainer4)
        Me.Panel3.Location = New System.Drawing.Point(242, 47)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(282, 204)
        Me.Panel3.TabIndex = 4
        '
        'DDContainer4
        '
        Me.DDContainer4.BackColor = System.Drawing.Color.Transparent
        Me.DDContainer4.ButtonBackColor = System.Drawing.Color.MistyRose
        Me.DDContainer4.ButtonBorder = System.Drawing.Color.LightCoral
        Me.DDContainer4.ButtonForeColor = System.Drawing.Color.Red
        Me.DDContainer4.ButtonHighlight = System.Drawing.Color.LightCoral
        Me.DDContainer4.ButtonShape = DropDownContainer.DDContainer.eButtonShape.Circle
        Me.DDContainer4.Controls.Add(Me.Panel7)
        Me.DDContainer4.DDAlignment = System.Drawing.StringAlignment.Near
        Me.DDContainer4.DDBackColor = System.Drawing.Color.SeaShell
        Me.DDContainer4.DDOpacity = 0.75
        Me.DDContainer4.DDPadding = New System.Windows.Forms.Padding(10)
        Me.DDContainer4.DDShadow = False
        Me.DDContainer4.DropControl = Me.Panel7
        Me.DDContainer4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DDContainer4.GraphicBorderColor = System.Drawing.Color.Transparent
        Me.DDContainer4.GraphicImage = CType(resources.GetObject("DDContainer4.GraphicImage"), System.Drawing.Bitmap)
        Me.DDContainer4.HeaderHeight = 20
        Me.DDContainer4.HeaderWidth = 242
        Me.DDContainer4.Location = New System.Drawing.Point(21, 39)
        Me.DDContainer4.Name = "DDContainer4"
        Me.DDContainer4.PanelSize = New System.Drawing.Size(156, 98)
        Me.DDContainer4.PushPinState = DropDownContainer.DDContainer.ePushPinState.Up
        Me.DDContainer4.Size = New System.Drawing.Size(242, 21)
        Me.DDContainer4.TabIndex = 3
        Me.DDContainer4.Text = "Over a Picture"
        Me.DDContainer4.TextAlignment = System.Drawing.StringAlignment.Center
        Me.DDContainer4.TextBoxBackColorA = System.Drawing.Color.Transparent
        Me.DDContainer4.TextBoxBackColorB = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DDContainer4.TextBoxBorderColor = System.Drawing.Color.Chocolate
        Me.DDContainer4.TextBoxGradientType = DropDownContainer.DDContainer.eGradientType.Vertical
        Me.DDContainer4.TextShadow = True
        Me.DDContainer4.TextShadowColor = System.Drawing.Color.WhiteSmoke
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.MistyRose
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.CheckedListBox1)
        Me.Panel7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel7.Location = New System.Drawing.Point(10, 32)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(136, 78)
        Me.Panel7.TabIndex = 12
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.BackColor = System.Drawing.Color.MistyRose
        Me.CheckedListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.CheckedListBox1.CheckOnClick = True
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Items.AddRange(New Object() {"Fly By Night", "Moving Pictures", "Hemispheres", "Permanent Waves"})
        Me.CheckedListBox1.Location = New System.Drawing.Point(8, 7)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(123, 75)
        Me.CheckedListBox1.TabIndex = 5
        '
        'ddcPictures
        '
        Me.ddcPictures.BackColor = System.Drawing.Color.Transparent
        Me.ddcPictures.ButtonBackColor = System.Drawing.Color.Transparent
        Me.ddcPictures.ButtonBorder = System.Drawing.Color.White
        Me.ddcPictures.ButtonForeColor = System.Drawing.Color.White
        Me.ddcPictures.ButtonHighlight = System.Drawing.Color.Transparent
        Me.ddcPictures.ButtonShape = DropDownContainer.DDContainer.eButtonShape.Circle
        Me.ddcPictures.Controls.Add(Me.PanelPics)
        Me.ddcPictures.DDAlignment = System.Drawing.StringAlignment.Near
        Me.ddcPictures.DDOpacity = 1
        Me.ddcPictures.DropControl = Me.PanelPics
        Me.ddcPictures.ForeColor = System.Drawing.Color.White
        Me.ddcPictures.GraphicBorderColor = System.Drawing.Color.White
        Me.ddcPictures.GraphicImage = Nothing
        Me.ddcPictures.HeaderHeight = 20
        Me.ddcPictures.HeaderWidth = 268
        Me.ddcPictures.Location = New System.Drawing.Point(8, 181)
        Me.ddcPictures.Name = "ddcPictures"
        Me.ddcPictures.PanelSize = New System.Drawing.Size(466, 214)
        Me.ddcPictures.Pin = System.Drawing.Color.White
        Me.ddcPictures.PinBody = System.Drawing.Color.Transparent
        Me.ddcPictures.PinHighlight = System.Drawing.Color.Transparent
        Me.ddcPictures.PinOutline = System.Drawing.Color.White
        Me.ddcPictures.PushPinState = DropDownContainer.DDContainer.ePushPinState.Up
        Me.ddcPictures.ShowPushPin = True
        Me.ddcPictures.Size = New System.Drawing.Size(268, 21)
        Me.ddcPictures.TabIndex = 28
        Me.ddcPictures.Text = "Open Me"
        Me.ddcPictures.TextAlignment = System.Drawing.StringAlignment.Center
        Me.ddcPictures.TextBoxBackColorA = System.Drawing.Color.Transparent
        Me.ddcPictures.TextBoxBorderColor = System.Drawing.Color.White
        Me.ddcPictures.TextBoxGradientType = DropDownContainer.DDContainer.eGradientType.Solid
        Me.ddcPictures.TextShadowColor = System.Drawing.Color.Black
        '
        'PanelPics
        '
        Me.PanelPics.Controls.Add(Me.butClear)
        Me.PanelPics.Controls.Add(Me.TabControl1)
        Me.PanelPics.Location = New System.Drawing.Point(0, 22)
        Me.PanelPics.Name = "PanelPics"
        Me.PanelPics.Size = New System.Drawing.Size(466, 214)
        Me.PanelPics.TabIndex = 29
        '
        'butClear
        '
        Me.butClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.butClear.Location = New System.Drawing.Point(272, 6)
        Me.butClear.Name = "butClear"
        Me.butClear.Size = New System.Drawing.Size(119, 23)
        Me.butClear.TabIndex = 27
        Me.butClear.Text = "Clear Selection"
        Me.butClear.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(8, 13)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(452, 195)
        Me.TabControl1.TabIndex = 26
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Jack)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(444, 169)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Jack"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Jack
        '
        Me.Jack.Image = CType(resources.GetObject("Jack.Image"), System.Drawing.Image)
        Me.Jack.Location = New System.Drawing.Point(161, 6)
        Me.Jack.Name = "Jack"
        Me.Jack.Size = New System.Drawing.Size(122, 154)
        Me.Jack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Jack.TabIndex = 0
        Me.Jack.TabStop = False
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Evolution)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(444, 169)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Evolution"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Evolution
        '
        Me.Evolution.Image = CType(resources.GetObject("Evolution.Image"), System.Drawing.Image)
        Me.Evolution.Location = New System.Drawing.Point(3, 6)
        Me.Evolution.Name = "Evolution"
        Me.Evolution.Size = New System.Drawing.Size(441, 157)
        Me.Evolution.TabIndex = 18
        Me.Evolution.TabStop = False
        '
        'ddcScrollPanel
        '
        Me.ddcScrollPanel.ButtonShape = DropDownContainer.DDContainer.eButtonShape.Circle
        Me.ddcScrollPanel.Controls.Add(Me.Panel5)
        Me.ddcScrollPanel.DDAlignment = System.Drawing.StringAlignment.Center
        Me.ddcScrollPanel.DDOpacity = 1
        Me.ddcScrollPanel.DropControl = Me.Panel5
        Me.ddcScrollPanel.GraphicAutoWidth = False
        Me.ddcScrollPanel.GraphicImage = Nothing
        Me.ddcScrollPanel.HeaderHeight = 20
        Me.ddcScrollPanel.HeaderWidth = 171
        Me.ddcScrollPanel.Location = New System.Drawing.Point(14, 138)
        Me.ddcScrollPanel.Name = "ddcScrollPanel"
        Me.ddcScrollPanel.PanelSize = New System.Drawing.Size(95, 174)
        Me.ddcScrollPanel.PushPinState = DropDownContainer.DDContainer.ePushPinState.Up
        Me.ddcScrollPanel.Size = New System.Drawing.Size(171, 21)
        Me.ddcScrollPanel.TabIndex = 10
        Me.ddcScrollPanel.Text = "ScrollPanel"
        Me.ddcScrollPanel.TextAlignment = System.Drawing.StringAlignment.Center
        Me.ddcScrollPanel.TextBoxBackColorA = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ddcScrollPanel.TextBoxBackColorB = System.Drawing.Color.LightYellow
        Me.ddcScrollPanel.TextBoxCornerRadius = 3
        Me.ddcScrollPanel.TextBoxGradientType = DropDownContainer.DDContainer.eGradientType.ForwardDiagonal
        '
        'Panel5
        '
        Me.Panel5.AutoScroll = True
        Me.Panel5.BackColor = System.Drawing.Color.RoyalBlue
        Me.Panel5.Controls.Add(Me.Button11)
        Me.Panel5.Controls.Add(Me.Button10)
        Me.Panel5.Controls.Add(Me.Button9)
        Me.Panel5.Controls.Add(Me.Button8)
        Me.Panel5.Controls.Add(Me.Button7)
        Me.Panel5.Controls.Add(Me.Button6)
        Me.Panel5.Controls.Add(Me.Button5)
        Me.Panel5.Controls.Add(Me.Button2)
        Me.Panel5.Location = New System.Drawing.Point(0, 22)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(95, 174)
        Me.Panel5.TabIndex = 9
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.LightYellow
        Me.Button11.FlatAppearance.BorderSize = 2
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.ForeColor = System.Drawing.Color.Red
        Me.Button11.Location = New System.Drawing.Point(13, 395)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(51, 47)
        Me.Button11.TabIndex = 0
        Me.Button11.Text = "8"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.LightYellow
        Me.Button10.FlatAppearance.BorderSize = 2
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.Red
        Me.Button10.Location = New System.Drawing.Point(13, 340)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(51, 47)
        Me.Button10.TabIndex = 0
        Me.Button10.Text = "7"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.LightYellow
        Me.Button9.FlatAppearance.BorderSize = 2
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.Red
        Me.Button9.Location = New System.Drawing.Point(13, 285)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(51, 47)
        Me.Button9.TabIndex = 0
        Me.Button9.Text = "6"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.LightYellow
        Me.Button8.FlatAppearance.BorderSize = 2
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.Red
        Me.Button8.Location = New System.Drawing.Point(13, 230)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(51, 47)
        Me.Button8.TabIndex = 0
        Me.Button8.Text = "5"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.LightYellow
        Me.Button7.FlatAppearance.BorderSize = 2
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.Red
        Me.Button7.Location = New System.Drawing.Point(13, 175)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(51, 47)
        Me.Button7.TabIndex = 0
        Me.Button7.Text = "4"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.LightYellow
        Me.Button6.FlatAppearance.BorderSize = 2
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.Red
        Me.Button6.Location = New System.Drawing.Point(13, 120)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(51, 47)
        Me.Button6.TabIndex = 0
        Me.Button6.Text = "3"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.LightYellow
        Me.Button5.FlatAppearance.BorderSize = 2
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.Red
        Me.Button5.Location = New System.Drawing.Point(13, 65)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(51, 47)
        Me.Button5.TabIndex = 0
        Me.Button5.Text = "2"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.LightYellow
        Me.Button2.FlatAppearance.BorderSize = 2
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.Red
        Me.Button2.Location = New System.Drawing.Point(13, 10)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(51, 47)
        Me.Button2.TabIndex = 0
        Me.Button2.Text = "1"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'ddcRadioButtons
        '
        Me.ddcRadioButtons.ButtonBackColor = System.Drawing.Color.DarkGray
        Me.ddcRadioButtons.ButtonBorder = System.Drawing.Color.DarkGray
        Me.ddcRadioButtons.ButtonForeColor = System.Drawing.Color.Red
        Me.ddcRadioButtons.ButtonShape = DropDownContainer.DDContainer.eButtonShape.Circle
        Me.ddcRadioButtons.Controls.Add(Me.Panel4)
        Me.ddcRadioButtons.DDAlignment = System.Drawing.StringAlignment.Near
        Me.ddcRadioButtons.DDOpacity = 1
        Me.ddcRadioButtons.DDShadow = False
        Me.ddcRadioButtons.DropControl = Me.Panel4
        Me.ddcRadioButtons.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ddcRadioButtons.ForeColor = System.Drawing.Color.Firebrick
        Me.ddcRadioButtons.GraphicAutoWidth = False
        Me.ddcRadioButtons.GraphicBorderColor = System.Drawing.Color.Red
        Me.ddcRadioButtons.GraphicImage = CType(resources.GetObject("ddcRadioButtons.GraphicImage"), System.Drawing.Bitmap)
        Me.ddcRadioButtons.GraphicWidth = 25
        Me.ddcRadioButtons.HeaderHeight = 20
        Me.ddcRadioButtons.HeaderWidth = 192
        Me.ddcRadioButtons.Location = New System.Drawing.Point(14, 184)
        Me.ddcRadioButtons.Name = "ddcRadioButtons"
        Me.ddcRadioButtons.PanelSize = New System.Drawing.Size(241, 194)
        Me.ddcRadioButtons.PushPinState = DropDownContainer.DDContainer.ePushPinState.Up
        Me.ddcRadioButtons.Size = New System.Drawing.Size(192, 21)
        Me.ddcRadioButtons.TabIndex = 6
        Me.ddcRadioButtons.Text = "Diver Down"
        Me.ddcRadioButtons.TextAlignment = System.Drawing.StringAlignment.Center
        Me.ddcRadioButtons.TextBoxBackColorB = System.Drawing.Color.DimGray
        Me.ddcRadioButtons.TextBoxCornerRadius = 7
        Me.ddcRadioButtons.TextBoxGradientType = DropDownContainer.DDContainer.eGradientType.Vertical
        Me.ddcRadioButtons.TextShadow = True
        Me.ddcRadioButtons.TextShadowColor = System.Drawing.Color.White
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.White
        Me.Panel4.BackgroundImage = CType(resources.GetObject("Panel4.BackgroundImage"), System.Drawing.Image)
        Me.Panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel4.Controls.Add(Me.RadioButton4)
        Me.Panel4.Controls.Add(Me.RadioButton1)
        Me.Panel4.Controls.Add(Me.RadioButton3)
        Me.Panel4.Controls.Add(Me.RadioButton2)
        Me.Panel4.Location = New System.Drawing.Point(0, 22)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(241, 194)
        Me.Panel4.TabIndex = 6
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton4.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton4.ForeColor = System.Drawing.Color.DarkBlue
        Me.RadioButton4.Location = New System.Drawing.Point(47, 134)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(148, 33)
        Me.RadioButton4.TabIndex = 0
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "Sherwood"
        Me.RadioButton4.UseVisualStyleBackColor = False
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton1.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton1.ForeColor = System.Drawing.Color.DarkBlue
        Me.RadioButton1.Location = New System.Drawing.Point(47, 11)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(112, 33)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Atomic"
        Me.RadioButton1.UseVisualStyleBackColor = False
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton3.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton3.ForeColor = System.Drawing.Color.DarkBlue
        Me.RadioButton3.Location = New System.Drawing.Point(47, 93)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(136, 33)
        Me.RadioButton3.TabIndex = 0
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "USDivers"
        Me.RadioButton3.UseVisualStyleBackColor = False
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton2.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton2.ForeColor = System.Drawing.Color.DarkBlue
        Me.RadioButton2.Location = New System.Drawing.Point(47, 52)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(142, 33)
        Me.RadioButton2.TabIndex = 0
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Scubapro"
        Me.RadioButton2.UseVisualStyleBackColor = False
        '
        'ddcCalendar
        '
        Me.ddcCalendar.ButtonBackColor = System.Drawing.Color.DarkBlue
        Me.ddcCalendar.ButtonBorder = System.Drawing.Color.Indigo
        Me.ddcCalendar.ButtonForeColor = System.Drawing.Color.White
        Me.ddcCalendar.ButtonHighlight = System.Drawing.Color.PowderBlue
        Me.ddcCalendar.ButtonShape = DropDownContainer.DDContainer.eButtonShape.Circle
        Me.ddcCalendar.Controls.Add(Me.MonthCalendar1)
        Me.ddcCalendar.DDAlignment = System.Drawing.StringAlignment.Near
        Me.ddcCalendar.DDOpacity = 1
        Me.ddcCalendar.DDPadding = New System.Windows.Forms.Padding(2)
        Me.ddcCalendar.DropControl = Me.MonthCalendar1
        Me.ddcCalendar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ddcCalendar.GraphicAutoWidth = False
        Me.ddcCalendar.GraphicImage = Nothing
        Me.ddcCalendar.HeaderHeight = 20
        Me.ddcCalendar.HeaderWidth = 217
        Me.ddcCalendar.Location = New System.Drawing.Point(14, 46)
        Me.ddcCalendar.Name = "ddcCalendar"
        Me.ddcCalendar.PanelSize = New System.Drawing.Size(182, 159)
        Me.ddcCalendar.Pin = System.Drawing.Color.Red
        Me.ddcCalendar.PinBody = System.Drawing.Color.Teal
        Me.ddcCalendar.PinOutline = System.Drawing.Color.DarkSlateGray
        Me.ddcCalendar.PushPinState = DropDownContainer.DDContainer.ePushPinState.Up
        Me.ddcCalendar.ShowPushPin = True
        Me.ddcCalendar.Size = New System.Drawing.Size(217, 21)
        Me.ddcCalendar.TabIndex = 8
        Me.ddcCalendar.Text = "Pick a Date"
        Me.ddcCalendar.TextAlignment = System.Drawing.StringAlignment.Center
        Me.ddcCalendar.TextBoxBackColorA = System.Drawing.Color.Maroon
        Me.ddcCalendar.TextBoxBackColorB = System.Drawing.Color.MistyRose
        Me.ddcCalendar.TextBoxBorderColor = System.Drawing.Color.SaddleBrown
        Me.ddcCalendar.TextBoxCornerRadius = 9
        Me.ddcCalendar.TextBoxGradientType = DropDownContainer.DDContainer.eGradientType.BackwardDiagonal
        '
        'MonthCalendar1
        '
        Me.MonthCalendar1.Location = New System.Drawing.Point(2, 24)
        Me.MonthCalendar1.MaxSelectionCount = 1
        Me.MonthCalendar1.Name = "MonthCalendar1"
        Me.MonthCalendar1.TabIndex = 0
        '
        'ddcShape
        '
        Me.ddcShape.ButtonShape = DropDownContainer.DDContainer.eButtonShape.Square
        Me.ddcShape.Controls.Add(Me.Panel1)
        Me.ddcShape.DDAlignment = System.Drawing.StringAlignment.Near
        Me.ddcShape.DDOpacity = 1
        Me.ddcShape.DropControl = Me.Panel1
        Me.ddcShape.GraphicAutoWidth = False
        Me.ddcShape.GraphicBorderColor = System.Drawing.Color.Navy
        Me.ddcShape.GraphicImage = Nothing
        Me.ddcShape.HeaderHeight = 20
        Me.ddcShape.HeaderWidth = 192
        Me.ddcShape.Location = New System.Drawing.Point(14, 92)
        Me.ddcShape.Name = "ddcShape"
        Me.ddcShape.PanelSize = New System.Drawing.Size(98, 88)
        Me.ddcShape.PushPinState = DropDownContainer.DDContainer.ePushPinState.Up
        Me.ddcShape.ShowPushPin = True
        Me.ddcShape.Size = New System.Drawing.Size(192, 21)
        Me.ddcShape.TabIndex = 0
        Me.ddcShape.Text = "Choose Shape"
        Me.ddcShape.TextAlignment = System.Drawing.StringAlignment.Center
        Me.ddcShape.TextBoxBackColorA = System.Drawing.Color.AliceBlue
        Me.ddcShape.TextBoxBackColorB = System.Drawing.Color.LightSteelBlue
        Me.ddcShape.TextBoxBorderColor = System.Drawing.Color.Navy
        Me.ddcShape.TextBoxCornerRadius = 0
        Me.ddcShape.TextBoxGradientType = DropDownContainer.DDContainer.eGradientType.Vertical
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.AliceBlue
        Me.Panel1.Controls.Add(Me.RadioButton5)
        Me.Panel1.Controls.Add(Me.RadioButton6)
        Me.Panel1.Controls.Add(Me.RadioButton7)
        Me.Panel1.Location = New System.Drawing.Point(0, 22)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(98, 88)
        Me.Panel1.TabIndex = 1
        '
        'RadioButton5
        '
        Me.RadioButton5.AutoSize = True
        Me.RadioButton5.Location = New System.Drawing.Point(14, 58)
        Me.RadioButton5.Name = "RadioButton5"
        Me.RadioButton5.Size = New System.Drawing.Size(74, 17)
        Me.RadioButton5.TabIndex = 2
        Me.RadioButton5.TabStop = True
        Me.RadioButton5.Text = "Rectangle"
        Me.RadioButton5.UseVisualStyleBackColor = True
        '
        'RadioButton6
        '
        Me.RadioButton6.AutoSize = True
        Me.RadioButton6.Location = New System.Drawing.Point(14, 35)
        Me.RadioButton6.Name = "RadioButton6"
        Me.RadioButton6.Size = New System.Drawing.Size(55, 17)
        Me.RadioButton6.TabIndex = 1
        Me.RadioButton6.TabStop = True
        Me.RadioButton6.Text = "Ellipse"
        Me.RadioButton6.UseVisualStyleBackColor = True
        '
        'RadioButton7
        '
        Me.RadioButton7.AutoSize = True
        Me.RadioButton7.Location = New System.Drawing.Point(14, 12)
        Me.RadioButton7.Name = "RadioButton7"
        Me.RadioButton7.Size = New System.Drawing.Size(51, 17)
        Me.RadioButton7.TabIndex = 0
        Me.RadioButton7.TabStop = True
        Me.RadioButton7.Text = "None"
        Me.RadioButton7.UseVisualStyleBackColor = True
        '
        'DDContainer1
        '
        Me.DDContainer1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DDContainer1.ButtonBackColor = System.Drawing.Color.PaleGreen
        Me.DDContainer1.ButtonBorder = System.Drawing.Color.ForestGreen
        Me.DDContainer1.ButtonForeColor = System.Drawing.Color.Green
        Me.DDContainer1.ButtonShape = DropDownContainer.DDContainer.eButtonShape.Circle
        Me.DDContainer1.Controls.Add(Me.Panel2)
        Me.DDContainer1.DDAlignment = System.Drawing.StringAlignment.Far
        Me.DDContainer1.DDOpacity = 1
        Me.DDContainer1.DropControl = Me.Panel2
        Me.DDContainer1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DDContainer1.ForeColor = System.Drawing.Color.DarkGreen
        Me.DDContainer1.GraphicAutoWidth = False
        Me.DDContainer1.GraphicImage = Nothing
        Me.DDContainer1.HeaderHeight = 20
        Me.DDContainer1.HeaderWidth = 450
        Me.DDContainer1.Location = New System.Drawing.Point(74, 12)
        Me.DDContainer1.Name = "DDContainer1"
        Me.DDContainer1.PanelSize = New System.Drawing.Size(147, 124)
        Me.DDContainer1.PinBody = System.Drawing.Color.Green
        Me.DDContainer1.PinOutline = System.Drawing.Color.DarkGreen
        Me.DDContainer1.PushPinState = DropDownContainer.DDContainer.ePushPinState.Up
        Me.DDContainer1.ShowPushPin = True
        Me.DDContainer1.Size = New System.Drawing.Size(450, 21)
        Me.DDContainer1.TabIndex = 0
        Me.DDContainer1.Text = "Anchored"
        Me.DDContainer1.TextAlignment = System.Drawing.StringAlignment.Center
        Me.DDContainer1.TextBoxBackColorA = System.Drawing.Color.Honeydew
        Me.DDContainer1.TextBoxBackColorB = System.Drawing.Color.LimeGreen
        Me.DDContainer1.TextBoxGradientType = DropDownContainer.DDContainer.eGradientType.Horizontal
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Honeydew
        Me.Panel2.Controls.Add(Me.ComboBox2)
        Me.Panel2.Controls.Add(Me.CheckBox2)
        Me.Panel2.Controls.Add(Me.Button3)
        Me.Panel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.Location = New System.Drawing.Point(0, 22)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(147, 124)
        Me.Panel2.TabIndex = 2
        '
        'ComboBox2
        '
        Me.ComboBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"ComboBox", "ComboBox 1", "ComboBox 2", "ComboBox 3", "ComboBox 4"})
        Me.ComboBox2.Location = New System.Drawing.Point(14, 9)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 3
        Me.ComboBox2.Text = "ComboBox"
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.Location = New System.Drawing.Point(36, 53)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(75, 17)
        Me.CheckBox2.TabIndex = 1
        Me.CheckBox2.Text = "CheckBox"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(60, 92)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 0
        Me.Button3.Text = "Close"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'ddcTreeview
        '
        Me.ddcTreeview.ButtonBackColor = System.Drawing.Color.MediumPurple
        Me.ddcTreeview.ButtonBorder = System.Drawing.Color.Indigo
        Me.ddcTreeview.ButtonHighlight = System.Drawing.Color.LavenderBlush
        Me.ddcTreeview.ButtonShape = DropDownContainer.DDContainer.eButtonShape.Square
        Me.ddcTreeview.Controls.Add(Me.Panel6)
        Me.ddcTreeview.DDAlignment = System.Drawing.StringAlignment.Near
        Me.ddcTreeview.DDOpacity = 1
        Me.ddcTreeview.DropControl = Me.Panel6
        Me.ddcTreeview.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ddcTreeview.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ddcTreeview.GraphicAutoWidth = False
        Me.ddcTreeview.GraphicImage = Nothing
        Me.ddcTreeview.HeaderHeight = 20
        Me.ddcTreeview.HeaderWidth = 217
        Me.ddcTreeview.Location = New System.Drawing.Point(14, 230)
        Me.ddcTreeview.Name = "ddcTreeview"
        Me.ddcTreeview.PanelSize = New System.Drawing.Size(180, 100)
        Me.ddcTreeview.PushPinState = DropDownContainer.DDContainer.ePushPinState.Up
        Me.ddcTreeview.Size = New System.Drawing.Size(217, 21)
        Me.ddcTreeview.TabIndex = 11
        Me.ddcTreeview.Text = "TreeView"
        Me.ddcTreeview.TextAlignment = System.Drawing.StringAlignment.Center
        Me.ddcTreeview.TextBoxBackColorA = System.Drawing.Color.LavenderBlush
        Me.ddcTreeview.TextBoxBackColorB = System.Drawing.Color.MediumPurple
        Me.ddcTreeview.TextBoxBorderColor = System.Drawing.Color.Indigo
        Me.ddcTreeview.TextBoxCornerRadius = 8
        Me.ddcTreeview.TextBoxGradientType = DropDownContainer.DDContainer.eGradientType.Vertical
        Me.ddcTreeview.TextShadow = True
        Me.ddcTreeview.TextShadowColor = System.Drawing.Color.Thistle
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.TreeView1)
        Me.Panel6.Location = New System.Drawing.Point(0, 22)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(180, 100)
        Me.Panel6.TabIndex = 15
        '
        'TreeView1
        '
        Me.TreeView1.BackColor = System.Drawing.Color.LightPink
        Me.TreeView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TreeView1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView1.ForeColor = System.Drawing.Color.DarkRed
        Me.TreeView1.LineColor = System.Drawing.Color.DarkRed
        Me.TreeView1.Location = New System.Drawing.Point(0, 0)
        Me.TreeView1.Name = "TreeView1"
        TreeNode1.Name = "Node0"
        TreeNode1.Text = "Node0"
        TreeNode2.Name = "Node7"
        TreeNode2.Text = "Node7"
        TreeNode3.Name = "Node11"
        TreeNode3.Text = "Node11"
        TreeNode4.Name = "Node10"
        TreeNode4.Text = "Node10"
        TreeNode5.Name = "Node8"
        TreeNode5.Text = "Node8"
        TreeNode6.Name = "Node9"
        TreeNode6.Text = "Node9"
        TreeNode7.Name = "Node5"
        TreeNode7.Text = "Node5"
        TreeNode8.Name = "Node6"
        TreeNode8.Text = "Node6"
        TreeNode9.Name = "Node1"
        TreeNode9.Text = "Node1"
        TreeNode10.Name = "Node2"
        TreeNode10.Text = "Node2"
        TreeNode11.Name = "Node12"
        TreeNode11.Text = "Node12"
        TreeNode12.Name = "Node13"
        TreeNode12.Text = "Node13"
        TreeNode13.Name = "Node3"
        TreeNode13.Text = "Node3"
        TreeNode14.Name = "Node4"
        TreeNode14.Text = "Node4"
        Me.TreeView1.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode1, TreeNode9, TreeNode10, TreeNode13, TreeNode14})
        Me.TreeView1.Size = New System.Drawing.Size(180, 100)
        Me.TreeView1.TabIndex = 14
        '
        'ddcNoText
        '
        Me.ddcNoText.ButtonBackColor = System.Drawing.Color.Plum
        Me.ddcNoText.ButtonShape = DropDownContainer.DDContainer.eButtonShape.Circle
        Me.ddcNoText.Controls.Add(Me.butRndKnownColor)
        Me.ddcNoText.DDAlignment = System.Drawing.StringAlignment.Near
        Me.ddcNoText.DDBackColor = System.Drawing.Color.Red
        Me.ddcNoText.DDOpacity = 1
        Me.ddcNoText.DDPadding = New System.Windows.Forms.Padding(5)
        Me.ddcNoText.DropControl = Me.butRndKnownColor
        Me.ddcNoText.GraphicAutoWidth = False
        Me.ddcNoText.GraphicImage = Nothing
        Me.ddcNoText.HeaderHeight = 20
        Me.ddcNoText.HeaderWidth = 44
        Me.ddcNoText.Location = New System.Drawing.Point(14, 12)
        Me.ddcNoText.Name = "ddcNoText"
        Me.ddcNoText.PanelSize = New System.Drawing.Size(176, 114)
        Me.ddcNoText.PinBody = System.Drawing.Color.White
        Me.ddcNoText.PinHighlight = System.Drawing.Color.Plum
        Me.ddcNoText.PushPinState = DropDownContainer.DDContainer.ePushPinState.Up
        Me.ddcNoText.ShowPushPin = True
        Me.ddcNoText.Size = New System.Drawing.Size(44, 21)
        Me.ddcNoText.TabIndex = 7
        Me.ddcNoText.TextAlignment = System.Drawing.StringAlignment.Center
        Me.ddcNoText.TextBoxGradientType = DropDownContainer.DDContainer.eGradientType.Solid
        '
        'butRndKnownColor
        '
        Me.butRndKnownColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.butRndKnownColor.Location = New System.Drawing.Point(5, 27)
        Me.butRndKnownColor.Name = "butRndKnownColor"
        Me.butRndKnownColor.Size = New System.Drawing.Size(166, 104)
        Me.butRndKnownColor.TabIndex = 8
        Me.butRndKnownColor.Text = "Single Button Control with DDPadding Border (Click Me)"
        Me.butRndKnownColor.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(536, 262)
        Me.Controls.Add(Me.DDContainer1)
        Me.Controls.Add(Me.ddcCalendar)
        Me.Controls.Add(Me.ddcShape)
        Me.Controls.Add(Me.ddcScrollPanel)
        Me.Controls.Add(Me.ddcRadioButtons)
        Me.Controls.Add(Me.ddcTreeview)
        Me.Controls.Add(Me.ddcNoText)
        Me.Controls.Add(Me.Panel3)
        Me.MinimumSize = New System.Drawing.Size(544, 34)
        Me.Name = "Form1"
        Me.Text = "DropDownContainer"
        Me.Panel3.ResumeLayout(False)
        Me.DDContainer4.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.ddcPictures.ResumeLayout(False)
        Me.PanelPics.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.Jack, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.Evolution, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ddcScrollPanel.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.ddcRadioButtons.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ddcCalendar.ResumeLayout(False)
        Me.ddcShape.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.DDContainer1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ddcTreeview.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.ddcNoText.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents DDContainer1 As DropDownContainer.DDContainer
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents DDContainer4 As DropDownContainer.DDContainer
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents ddcRadioButtons As DropDownContainer.DDContainer
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents ddcNoText As DropDownContainer.DDContainer
    Friend WithEvents butRndKnownColor As System.Windows.Forms.Button
    Friend WithEvents ddcCalendar As DropDownContainer.DDContainer
    Friend WithEvents CheckedListBox1 As System.Windows.Forms.CheckedListBox
    Friend WithEvents MonthCalendar1 As System.Windows.Forms.MonthCalendar
    Friend WithEvents ddcShape As DropDownContainer.DDContainer
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents RadioButton5 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton6 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton7 As System.Windows.Forms.RadioButton
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ddcScrollPanel As DropDownContainer.DDContainer
    Friend WithEvents ddcTreeview As DropDownContainer.DDContainer
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents butClear As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Jack As System.Windows.Forms.PictureBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Evolution As System.Windows.Forms.PictureBox
    Friend WithEvents ddcPictures As DropDownContainer.DDContainer
    Friend WithEvents PanelPics As System.Windows.Forms.Panel

End Class
