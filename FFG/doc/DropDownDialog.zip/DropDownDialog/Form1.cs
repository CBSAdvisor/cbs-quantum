//================================================
//| Downloaded From                              |
//| Visual C# Kicks - http://www.vcskicks.com/   |
//================================================

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DropDownDialog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDropDown_Click(object sender, EventArgs e)
        {
            //The point just below the button
            Point location = this.PointToScreen(new Point(btnDropDown.Left, btnDropDown.Bottom));

            //get the dialog
            frmDialog dialog = new frmDialog(location);

            dialog.Show();
        }
    }
}